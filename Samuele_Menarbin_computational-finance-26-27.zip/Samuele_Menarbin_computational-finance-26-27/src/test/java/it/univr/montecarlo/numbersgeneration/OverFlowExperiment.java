package it.univr.montecarlo.numbersgeneration;

public class OverFlowExperiment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int valueOverflow = 1;
		int maximumIntegerValue=Integer.MAX_VALUE;
		System.out.println("The maximum int value is: " +maximumIntegerValue);
		
		int maximumIntegerValuePlusOverflow=maximumIntegerValue+valueOverflow;
		
		System.out.println("The maximum int value plus: " + valueOverflow + " is " + maximumIntegerValuePlusOverflow);
		
		//We learn that adding some to the maximum value, we expect a negative number, that however
		//in absolute value is bigger from others
		
		int minimumIntegerValue=Integer.MIN_VALUE;
		System.out.println("The minimum int value is :"+minimumIntegerValue);
		//We observe that the minimum corresponds to the 
		
		
		valueOverflow = 2;
		maximumIntegerValue=Integer.MAX_VALUE;
		System.out.println("The maximum int value is: " +maximumIntegerValue);
		
		maximumIntegerValuePlusOverflow=maximumIntegerValue+valueOverflow;
		
		System.out.println("The maximum int value plus: " + valueOverflow + " is " + maximumIntegerValuePlusOverflow);
		
		//We learn that adding some to the maximum value, we expect a negative number, that however
		//in absolute value is bigger from others
		
		minimumIntegerValue=Integer.MIN_VALUE;
		System.out.println("The minimum int value is :"+minimumIntegerValue);
		//We observe that the minimum corresponds to the
		
		
		valueOverflow = 3;
		maximumIntegerValue=Integer.MAX_VALUE;
		System.out.println("The maximum int value is: " +maximumIntegerValue);
		
		maximumIntegerValuePlusOverflow=maximumIntegerValue+valueOverflow;
		
		System.out.println("The maximum int value plus: " + valueOverflow + " is " + maximumIntegerValuePlusOverflow);
		
		//We learn that adding some to the maximum value, we expect a negative number, that however
		//in absolute value is bigger from others
		
		minimumIntegerValue=Integer.MIN_VALUE;
		System.out.println("The minimum int value is :"+minimumIntegerValue);
		//We observe that the minimum corresponds to the
		
		
		//In that case we obtain the maximum integer number
		int valueUnderflow = 1;
		int minimumIntegerValueMinusUnderflow = minimumIntegerValue - valueUnderflow;
		System.out.println("The minimum integer value minus "+valueUnderflow+" is "+minimumIntegerValueMinusUnderflow);
		
		
		valueUnderflow = 2;
		minimumIntegerValueMinusUnderflow = minimumIntegerValue - valueUnderflow;
		System.out.println("The minimum integer value minus "+valueUnderflow+" is "+minimumIntegerValueMinusUnderflow);
		
		long maximumLongValue = Long.MAX_VALUE;
		System.out.println("The maximum long value is "+maximumLongValue);
		long maximumLongValuePlusOne = maximumLongValue + 1;
		System.out.println("The maximum long value is "+maximumLongValuePlusOne);
		
		long minimumLongValue = Long.MIN_VALUE;
		System.out.println("The minimun long value is "+minimumLongValue);
		long minimumLongValuePlusOne = minimumLongValue - 1;
		System.out.println("The maximum long value is "+minimumLongValuePlusOne);
		
	}

}

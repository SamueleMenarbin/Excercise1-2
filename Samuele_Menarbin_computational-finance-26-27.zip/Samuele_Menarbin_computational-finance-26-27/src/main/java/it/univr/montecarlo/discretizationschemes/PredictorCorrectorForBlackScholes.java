package it.univr.montecarlo.discretizationschemes;

import net.finmath.montecarlo.BrownianMotion;
import net.finmath.stochastic.RandomVariable;
import net.finmath.time.TimeDiscretization;

public class PredictorCorrectorForBlackScholes extends AbstractProcessSimulation{
	
	
	private final double muDrift;// mu
	private final double sigmaVolatility;// sigma
	
	public PredictorCorrectorForBlackScholes(double muDrift, double sigmaVolatility, double initialValue, int numberOfSimulations, int seed, TimeDiscretization times) {
		super(initialValue, numberOfSimulations, seed, times);
		this.muDrift = muDrift;
		this.sigmaVolatility = sigmaVolatility;
		this.transform = (x -> x); //it is a field of DoubleUnaryOperation. In that case it means f(x) = x .  
		this.inverseTransform = (x -> x); //it is a field of DoubleUnaryOperation In that case it mean f(x) = x .
	}

	
	/**
	 * @author Samuele Menarbin
	 * 
	 * 
	 * Exercjse n.1
	 * 
	 * I create a new method, getPredictorCorrector that takes as an input the last realization and the corresponding time index.
	 * Then I apply the usual stochastic simulation, using the last realization received, keeping individually the drift and the diffusion terms.
	 * Finally I return the whole simulation that includes the last realization plus the drift term plus the diffusion term.
	 * This result comes back in the method getDrif when getPredictorCorrector is called. 
	 * 
	 **/
	
	protected RandomVariable getPredictorCorrector(RandomVariable lastRealization, int timeIndex) {
		TimeDiscretization times = getTimeDiscretization();
		final double timeStep = times.getTimeStep(timeIndex - 1);
		final RandomVariable drifPredictorCorrector=lastRealization.mult(muDrift).mult(timeStep);
		
		BrownianMotion brownianMotion = getStochasticDriver();
		final RandomVariable brownianIncrement = brownianMotion.getBrownianIncrement(timeIndex - 1, 0);
		final RandomVariable diffusionPredictorCorrector=lastRealization.mult(sigmaVolatility).mult(brownianIncrement);
		return lastRealization.add(drifPredictorCorrector).add(diffusionPredictorCorrector);
	}
	
	
	@Override
	protected RandomVariable getDrift(RandomVariable lastRealization, int timeIndex) {
		TimeDiscretization times = getTimeDiscretization();
		final double timeStep = times.getTimeStep(timeIndex - 1);
		return ((lastRealization.mult(0.5*muDrift).add(getPredictorCorrector(lastRealization, timeIndex).mult(0.5*muDrift)))).mult(timeStep);
	}

	
	@Override
	protected RandomVariable getDiffusion(RandomVariable lastRealization, int timeIndex) {
		BrownianMotion brownianMotion = getStochasticDriver();
		final RandomVariable brownianIncrement = brownianMotion.getBrownianIncrement(timeIndex - 1, 0);
		return lastRealization.mult(sigmaVolatility).mult(brownianIncrement);
	}
	
	

}

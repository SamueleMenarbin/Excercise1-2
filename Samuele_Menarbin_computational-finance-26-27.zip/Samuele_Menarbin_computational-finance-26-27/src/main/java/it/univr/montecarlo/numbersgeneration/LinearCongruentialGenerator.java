package it.univr.montecarlo.numbersgeneration;

import java.util.Random;

/**
 * This class generates pseudo random numbers through a linear congruential random number generator:
 * a linear congruential random number generator produces natural numbers
 *
 * x[i+1] =(a*x[i] + c) mod_m,
 *
 * where x[0] = seed, for appropriate values of natural numbers a, c and m (for big m).
 *
 * We have a method generate() which generates all the sequence (i.e., an array), up to the number of
 * pseudo random integers we want to simulate. We also have two public methods, getRandomNumberSequence()
 * and getNextInteger(), that return all the sequence and the next integer x[count + 1], where count
 * gets incremented by 1 every time the method is called, respectively.
 *
 * @author Andrea Mazzon
 *
 */
public class LinearCongruentialGenerator {

    private long[] randomNumbers;// array of long. Before that is initialized, its values are null, not zero.
    // upcasting necessary, the result of Math.pow(2, 48) is understood as an int
    private final long modulus = (long) Math.pow(2, 48);
    private long a = 25214903917L; // if I don't put L after the number, it will complain that is out of range
    private final long c = 11;// automatic upcasting
    private long seed; // it will be the first entry of our pseudo random number list
    private int numberOfPseudoRandomNumbers;
    private int count = 1;

    // constructor
    public LinearCongruentialGenerator(int numberOfPseudoRandomNumbers, long seed) {
        this.numberOfPseudoRandomNumbers = numberOfPseudoRandomNumbers;
        this.seed = seed;
    }

    // overloaded constructor: random seed
    public LinearCongruentialGenerator(int numberOfPseudoRandomNumbers) {
            this.numberOfPseudoRandomNumbers = numberOfPseudoRandomNumbers;
            Random seedGenerator = new Random();
            seed = Math.abs(seedGenerator.nextInt());
    }

    private void generate() {
        // initialization! + 1 because the first one is the seed
        randomNumbers = new long[numberOfPseudoRandomNumbers + 1]; //After this line of code, the array is initialized and now have as values, all zeros, instead of null
        randomNumbers[0] = seed; // the first entry is the seed: first number of the sequence
        for (int indexOfInteger = 0; indexOfInteger < numberOfPseudoRandomNumbers; indexOfInteger++) {
        	//randomNumbers[indexOfInteger + 1] = Math.abs((a * randomNumbers[indexOfInteger] + c)) % modulus;
        	randomNumbers[indexOfInteger + 1] = ((a * randomNumbers[indexOfInteger] + c) % modulus)+modulus; //always holds
        	//for the last iteration, indexOfInteger, would be equal to numberOfPseudoRandomNumbers - 1
        	//the reason why we could obtained negative values in this setting is due to an overflow, 
        	//caused by the too large dimension.
        	
        	//in order to solve this problem, we can do two things:
        	//i) set the absolute value to (a * randomNumbers[indexOfInteger] + c)
        	//ii)add modulus to the remainder of the operation, because for example the rest of -9/10 is -9 and adding 10, the modulus, we
        	//obtain e a positive number. In fact the rest of the division is always smaller than the modulus, 
        	//which in our case is the second term of the division
        }
    }
    

    /**
     * getter method for the sequence of pseudo random natural numbers
     *
     * @return the sequence of pseudo random numbers
     */
    public long[] getRandomNumberSequence() {
        // another use of encapsulation: we call the method generate() only once
        if (randomNumbers == null) //if it has not been initialized yet 
        {
            generate();
        }
        return randomNumbers; // returns the already generated sequence of numbers.
    }

    /**
     * @return the next number of the sequence of pseudo random numbers
     */
    public long getNextInteger() {
        long[] sequence = getRandomNumberSequence();// it gets really generated only once
        return sequence[count++];
        
        //Substantially with that method, you don't have to generate every time the all
        //path of simulated random numbers. In fact you generate it at the beginning and reuse later
        //the whole path before generated, in the first time. 
        
    }

    /**
     * getter method for the modulus
     *
     * @return the modulus of the congruence that generates the pseudo random
     *         numbers
     */
    public long getModulus() {
        return modulus;
    }

    /**
     * getter method for the length of the simulated sequence
     *
     * @return the length of the simulated sequence
     */
    public int getNumberOfPseudoRandomNumbers() {
        return numberOfPseudoRandomNumbers;
    }
} 
